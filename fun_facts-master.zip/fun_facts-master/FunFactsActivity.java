package com.projectstudio.funfacts;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FunFactsActivity extends AppCompatActivity {
    public static final String TAG = FunFactsActivity.class.getSimpleName();
    // Using the class FactBook as the data type and initializing it to create a new FactBook object.
    private FactBook mFactBook = new FactBook();
    private ColorWheel mColorWheel = new ColorWheel();
    private TextView mFactTextView;
    private Button mShowFactButton;
    private RelativeLayout mRelativeBackgroundColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // This method tells the activity which layout to use for the screen.
        // Layout gets attached to our activity.
        setContentView(R.layout.activity_fun_facts);

        // Assigning the Views from the layout file to the corresponding variables.
        mFactTextView = (TextView) findViewById(R.id.factTextView);
        mShowFactButton = (Button) findViewById(R.id.showFactButton);
        mRelativeBackgroundColor = (RelativeLayout) findViewById(R.id.relativeBackgroundColor);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            // The button was clicked, so update the fact TextView with a new fact.
            // Randomly selects a fact and then updates the screen with a dynamic fact.
            public void onClick(View v) {
                String fact = mFactBook.getFact();
                int color = mColorWheel.getColor();


                mFactTextView.setText(fact);
                mRelativeBackgroundColor.setBackgroundColor(color);
                mShowFactButton.setTextColor(color);
            }
        };
        mShowFactButton.setOnClickListener(listener);

        Toast.makeText(FunFactsActivity.this, "Activity Was Created!", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "We are logging from the onCreate method");
    }
}
