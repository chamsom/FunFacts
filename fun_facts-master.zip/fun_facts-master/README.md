# fun_facts
An Android app that utilizes 2 arrays for background colors &amp; facts.
